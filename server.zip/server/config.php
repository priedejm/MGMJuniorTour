<?php
// Local dev copy of config.example.php — gitignored. Real deployments must
// set a unique ADMIN_KEY here (and match it in .env's VITE_ADMIN_KEY) before
// building and uploading.
define('ADMIN_KEY', 'dev-local-admin-key');

define('DATA_DIR', __DIR__ . '/data');
define('UPLOAD_DIR', __DIR__ . '/assets/uploaded');
define('UPLOAD_URL_BASE', '/assets/uploaded');
